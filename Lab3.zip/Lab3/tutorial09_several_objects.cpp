// Assignment 09 - Suzanne ring with camera controls
// Build (Linux):
//   g++ assignment09.cpp -std=c++17 -lglfw -lGLEW -lGL -O2 -o assignment09
// Run next to suzanne.obj (and optional plane.bmp for extra credit).
//
// Controls:
//   w/s : move camera radius in/out
//   a/d : orbit left/right (azimuth)
//   Up/Down : orbit up/down (elevation)
//   L : toggle diffuse+specular
//   ESC : quit
//
// Note: Uses z as "up" so the ground is the z=0 plane.

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cfloat>
#include <algorithm>

#include "common/controls.hpp"
GLFWwindow* window = nullptr;    // the one and only definition


using namespace std;
using namespace glm;

static const char* kVertexShader = R"(#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;

uniform mat4 uMVP;
uniform mat4 uModel;
uniform mat3 uNormalMatrix;

out vec3 vPosWS;
out vec3 vNormalWS;
out vec2 vUV;

void main() {
    vec4 posWS = uModel * vec4(aPos, 1.0);
    vPosWS = posWS.xyz;
    vNormalWS = normalize(uNormalMatrix * aNormal);
    vUV = aUV;
    gl_Position = uMVP * vec4(aPos, 1.0);
}
)";

static const char* kFragmentShader = R"(#version 330 core
in vec3 vPosWS;
in vec3 vNormalWS;
in vec2 vUV;

out vec4 FragColor;

uniform vec3 uViewPos;
uniform vec3 uLightPos;
uniform vec3 uAmbient;     // ambient rgb
uniform vec3 uDiffuseCol;  // base color (used if no texture)
uniform vec3 uSpecularCol;
uniform float uShininess;
uniform int uEnableSD;     // 0 -> only ambient, 1 -> enable diffuse+specular
uniform int uUseTexture;   // 1 if sampling texture
uniform sampler2D uTex;

void main() {
    vec3 N = normalize(vNormalWS);
    vec3 L = normalize(uLightPos - vPosWS);
    vec3 V = normalize(uViewPos - vPosWS);
    vec3 H = normalize(L + V);

    // Ambient
    vec3 ambient = uAmbient;

    // Base albedo either from texture or uniform
    vec3 base = (uUseTexture == 1) ? texture(uTex, vUV).rgb : uDiffuseCol;

    // Diffuse (Lambert)
    float ndotl = max(dot(N, L), 0.0);
    vec3 diffuse = base * ndotl;

    // Specular (Blinn-Phong)
    float ndoth = max(dot(N, H), 0.0);
    vec3 spec = uSpecularCol * pow(ndoth, uShininess);

    vec3 color = ambient + (uEnableSD == 1 ? (diffuse + spec) : vec3(0.0));
    FragColor = vec4(color, 1.0);
}
)";

// Minimal shader compiler
GLuint compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if(!ok) {
        GLint len=0; glGetShaderiv(s, GL_INFO_LOG_LENGTH, &len);
        string log(len, '\0'); glGetShaderInfoLog(s, len, nullptr, log.data());
        fprintf(stderr, "Shader compile error:\n%s\n", log.c_str());
        exit(1);
    }
    return s;
}
GLuint linkProgram(GLuint vs, GLuint fs) {
    GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    GLint ok=0; glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if(!ok) {
        GLint len=0; glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
        string log(len, '\0'); glGetProgramInfoLog(prog, len, nullptr, log.data());
        fprintf(stderr, "Link error:\n%s\n", log.c_str());
        exit(1);
    }
    return prog;
}

// Very small OBJ loader: supports v/vt/vn and f with triangles/quads.
struct Mesh {
    vector<vec3> positions;
    vector<vec3> normals;
    vector<vec2> uvs;
    vector<unsigned> indices; // triangles
    vec3 bbMin{FLT_MAX}, bbMax{-FLT_MAX};
};
static void update_bbox(Mesh& m, const vec3& p){
    m.bbMin = glm::min(m.bbMin, p);
    m.bbMax = glm::max(m.bbMax, p);
}
bool loadOBJ(const string& path, Mesh& out) {
    vector<vec3> temp_pos;
    vector<vec3> temp_nrm;
    vector<vec2> temp_uv;

    struct Idx { int v=-1, t=-1, n=-1; };
    vector<Idx> faces;

    ifstream in(path);
    if(!in) return false;
    string line;
    while(getline(in, line)) {
        if(line.empty() || line[0]=='#') continue;
        stringstream ss(line);
        string tag; ss >> tag;
        if(tag=="v"){
            vec3 v; ss>>v.x>>v.y>>v.z; temp_pos.push_back(v);
        } else if(tag=="vt"){
            vec2 uv; ss>>uv.x>>uv.y; temp_uv.push_back(uv);
        } else if(tag=="vn"){
            vec3 n; ss>>n.x>>n.y>>n.z; temp_nrm.push_back(n);
        } else if(tag=="f"){
            vector<Idx> f;
            string w;
            while(ss>>w){
                Idx idx;
                // parse forms: v, v/t, v//n, v/t/n
                int v=-1,t=-1,n=-1;
                size_t s1=w.find('/');
                if(s1==string::npos){ v=stoi(w); }
                else{
                    string a=w.substr(0,s1); v = a.empty()?0:stoi(a);
                    size_t s2=w.find('/', s1+1);
                    if(s2==string::npos){ // v/t
                        string b=w.substr(s1+1);
                        t = b.empty()?0:stoi(b);
                    } else {
                        string b=w.substr(s1+1, s2-(s1+1));
                        string c=w.substr(s2+1);
                        t = b.empty()?0:stoi(b);
                        n = c.empty()?0:stoi(c);
                    }
                }
                idx.v = (v<0? (int)temp_pos.size()+v : v-1);
                if(t!=0) idx.t = (t<0? (int)temp_uv.size()+t : t-1);
                if(n!=0) idx.n = (n<0? (int)temp_nrm.size()+n : n-1);
                f.push_back(idx);
            }
            // triangulate polygon (fan)
            for(size_t i=1;i+1<f.size();++i){
                faces.push_back(f[0]);
                faces.push_back(f[i]);
                faces.push_back(f[i+1]);
            }
        }
    }
    // build indexed mesh (dedupe not implemented; simple expansion then index)
    // For simplicity, we create unique vertex per face-vertex and index sequentially.
    out.positions.clear(); out.normals.clear(); out.uvs.clear(); out.indices.clear();
    out.bbMin = vec3( FLT_MAX); out.bbMax = vec3(-FLT_MAX);
    out.positions.reserve(faces.size());
    out.normals.reserve(faces.size());
    out.uvs.reserve(faces.size());
    for(const auto& idx : faces){
        vec3 p = temp_pos.at(idx.v);
        vec3 n = (idx.n>=0 ? temp_nrm.at(idx.n) : vec3(0,0,1));
        vec2 uv = (idx.t>=0 ? temp_uv.at(idx.t) : vec2(0,0));
        out.indices.push_back((unsigned)out.positions.size());
        out.positions.push_back(p);
        out.normals.push_back(n);
        out.uvs.push_back(uv);
        update_bbox(out, p);
    }
    return true;
}

// Simple BMP loader (24-bit uncompressed). Returns GL texture or 0 on failure.
GLuint loadBMP(const string& imagepath) {
    FILE* file = fopen(imagepath.c_str(), "rb");
    if(!file) return 0;
    unsigned char header[54];
    if(fread(header,1,54,file)!=54){ fclose(file); return 0; }
    if(header[0]!='B' || header[1]!='M'){ fclose(file); return 0; }
    unsigned int dataPos = *(int*)&(header[0x0A]);
    unsigned int imageSize = *(int*)&(header[0x22]);
    unsigned int width     = *(int*)&(header[0x12]);
    unsigned int height    = *(int*)&(header[0x16]);
    if(imageSize==0) imageSize = width*height*3;
    if(dataPos==0) dataPos = 54;
    vector<unsigned char> data(imageSize);
    fread(data.data(),1,imageSize,file);
    fclose(file);

    GLuint tex; glGenTextures(1,&tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, data.data());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glGenerateMipmap(GL_TEXTURE_2D);
    return tex;
}

// Geometry for the ground rectangle (unit square, to be scaled)
void makePlane(vector<vec3>& pos, vector<vec3>& nrm, vector<vec2>& uv, vector<unsigned>& idx) {
    pos = { {-1,-1,0}, {1,-1,0}, {1,1,0}, {-1,1,0} };
    nrm = { {0,0,1}, {0,0,1}, {0,0,1}, {0,0,1} };
    uv  = { {0,0}, {1,0}, {1,1}, {0,1} };
    idx = { 0,1,2, 0,2,3 };
}

// Globals for camera control
float g_radius = 6.0f;    // distance from origin
float g_theta  = 0.0f;    // azimuth
float g_phi    = 0.6f;    // elevation (radians), clamp near (-pi/2, pi/2)
int g_enableSD = 1;       // diffuse+specular toggle

// Key handling
void handleKeys(GLFWwindow* win) {
    // radial in/out
    if(glfwGetKey(win, GLFW_KEY_W) == GLFW_PRESS) g_radius = std::max(0.5f, g_radius - 0.05f);
    if(glfwGetKey(win, GLFW_KEY_S) == GLFW_PRESS) g_radius = std::min(200.0f, g_radius + 0.05f);
    // orbit left/right
    if(glfwGetKey(win, GLFW_KEY_A) == GLFW_PRESS) g_theta += 0.02f;
    if(glfwGetKey(win, GLFW_KEY_D) == GLFW_PRESS) g_theta -= 0.02f;
    // orbit up/down
    if(glfwGetKey(win, GLFW_KEY_UP) == GLFW_PRESS)   g_phi = std::min( 1.45f, g_phi + 0.02f);
    if(glfwGetKey(win, GLFW_KEY_DOWN) == GLFW_PRESS) g_phi = std::max(-1.45f, g_phi - 0.02f);
}

// 'L' toggle needs edge detection
int g_prevL = GLFW_RELEASE;
void pollToggle(GLFWwindow* win) {
    int state = glfwGetKey(win, GLFW_KEY_L);
    if(state == GLFW_PRESS && g_prevL == GLFW_RELEASE) {
        g_enableSD = 1 - g_enableSD;
    }
    g_prevL = state;
}

int main() {
    if(!glfwInit()) { fprintf(stderr,"Failed to init GLFW\n"); return -1; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    window = glfwCreateWindow(1280, 800, "Assignment 09", nullptr, nullptr);
    if(!window){ fprintf(stderr,"Failed to open window.\n"); glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);



    // Disable mouse input (no cursor capture, no callbacks)
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
    glfwSetCursorPosCallback(window, nullptr);
    glfwSetMouseButtonCallback(window, nullptr);
    glfwSetScrollCallback(window, nullptr);
    glewExperimental = true;
    if(glewInit()!=GLEW_OK){ fprintf(stderr,"Failed to init GLEW\n"); return -1; }
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Shaders
    GLuint vs=compileShader(GL_VERTEX_SHADER, kVertexShader);
    GLuint fs=compileShader(GL_FRAGMENT_SHADER, kFragmentShader);
    GLuint prog=linkProgram(vs,fs);
    glDeleteShader(vs); glDeleteShader(fs);

    // Load Suzanne
    Mesh suz;
    if(!loadOBJ("suzanne.obj", suz)){
        fprintf(stderr, "Could not load suzanne.obj (place it next to the executable)\n");
        return -1;
    }

    // Compute dimensions for placement: width along local X (ear-to-ear), depth along local Y (nose back), height along Z
    float width  = suz.bbMax.x - suz.bbMin.x;
    float depth  = suz.bbMax.y - suz.bbMin.y;
    float height = suz.bbMax.z - suz.bbMin.z;
    // Circle radius so neighbors "ears" just touch: arc length = width = R * (2pi/8) -> R = width / (pi/4) = 4*width/pi
    float angleStep = 2.0f * float(M_PI) / 8.0f;
    float R = width / angleStep;

    // Chin to z=0: translate model up by -minZ so chin touches z=0
    float chinLift = -suz.bbMin.z;

    // Plane extents: just beyond the front of all heads -> R + (depth/2) + small margin
    float planeHalf = R + depth*0.5f + width*0.05f;

    // Create GL buffers for Suzanne
    GLuint vaoSuz, vboPosSuz, vboNrmSuz, vboUVSuz, eboSuz;
    glGenVertexArrays(1, &vaoSuz);
    glBindVertexArray(vaoSuz);
    glGenBuffers(1, &vboPosSuz);
    glBindBuffer(GL_ARRAY_BUFFER, vboPosSuz);
    glBufferData(GL_ARRAY_BUFFER, suz.positions.size()*sizeof(vec3), suz.positions.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(vec3),(void*)0);

    glGenBuffers(1, &vboNrmSuz);
    glBindBuffer(GL_ARRAY_BUFFER, vboNrmSuz);
    glBufferData(GL_ARRAY_BUFFER, suz.normals.size()*sizeof(vec3), suz.normals.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(vec3),(void*)0);

    glGenBuffers(1, &vboUVSuz);
    glBindBuffer(GL_ARRAY_BUFFER, vboUVSuz);
    glBufferData(GL_ARRAY_BUFFER, suz.uvs.size()*sizeof(vec2), suz.uvs.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(vec2),(void*)0);

    glGenBuffers(1, &eboSuz);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, eboSuz);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, suz.indices.size()*sizeof(unsigned), suz.indices.data(), GL_STATIC_DRAW);
    GLsizei suzIndexCount = (GLsizei)suz.indices.size();

    // Plane buffers
    vector<vec3> pPos, pNrm; vector<vec2> pUV; vector<unsigned> pIdx;
    makePlane(pPos, pNrm, pUV, pIdx);
    GLuint vaoPlane, vboPosPlane, vboNrmPlane, vboUVPlane, eboPlane;
    glGenVertexArrays(1, &vaoPlane);
    glBindVertexArray(vaoPlane);
    glGenBuffers(1, &vboPosPlane);
    glBindBuffer(GL_ARRAY_BUFFER, vboPosPlane);
    glBufferData(GL_ARRAY_BUFFER, pPos.size()*sizeof(vec3), pPos.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(vec3),(void*)0);

    glGenBuffers(1, &vboNrmPlane);
    glBindBuffer(GL_ARRAY_BUFFER, vboNrmPlane);
    glBufferData(GL_ARRAY_BUFFER, pNrm.size()*sizeof(vec3), pNrm.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(vec3),(void*)0);

    glGenBuffers(1, &vboUVPlane);
    glBindBuffer(GL_ARRAY_BUFFER, vboUVPlane);
    glBufferData(GL_ARRAY_BUFFER, pUV.size()*sizeof(vec2), pUV.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(vec2),(void*)0);

    glGenBuffers(1, &eboPlane);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, eboPlane);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, pIdx.size()*sizeof(unsigned), pIdx.data(), GL_STATIC_DRAW);
    GLsizei planeIndexCount = (GLsizei)pIdx.size();

    // Optional texture for plane (extra credit)
    GLuint planeTex = loadBMP("plane.bmp");
    int usePlaneTex = planeTex? 1 : 0;
    if(planeTex){
        glBindTexture(GL_TEXTURE_2D, planeTex);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    }

    // Uniform locations
    glUseProgram(prog);
    GLint locMVP = glGetUniformLocation(prog, "uMVP");
    GLint locModel = glGetUniformLocation(prog, "uModel");
    GLint locNrmMat = glGetUniformLocation(prog, "uNormalMatrix");
    GLint locViewPos = glGetUniformLocation(prog, "uViewPos");
    GLint locLightPos = glGetUniformLocation(prog, "uLightPos");
    GLint locAmbient = glGetUniformLocation(prog, "uAmbient");
    GLint locDiffuseCol = glGetUniformLocation(prog, "uDiffuseCol");
    GLint locSpecularCol = glGetUniformLocation(prog, "uSpecularCol");
    GLint locShininess = glGetUniformLocation(prog, "uShininess");
    GLint locEnableSD = glGetUniformLocation(prog, "uEnableSD");
    GLint locUseTexture = glGetUniformLocation(prog, "uUseTexture");
	GLint locTex = glGetUniformLocation(prog, "uTex");
    glUniform1i(locTex, 0);

    // Light and material
    vec3 lightPos = vec3(0.0f, 0.0f, 6.0f);
    vec3 ambient = vec3(0.08f, 0.08f, 0.08f);
    vec3 specCol = vec3(0.25f, 0.25f, 0.25f);
    float shininess = 32.0f;

    // Main loop
    while(!glfwWindowShouldClose(window)) {
        if(glfwGetKey(window, GLFW_KEY_ESCAPE)==GLFW_PRESS) glfwSetWindowShouldClose(window, true);
        handleKeys(window);
        pollToggle(window);

        int w,h; glfwGetFramebufferSize(window,&w,&h);
        glViewport(0,0,w,h);
        glClearColor(0.1f,0.1f,0.12f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

        // Camera from spherical coords, z-up
        vec3 cam = vec3(
            g_radius * cosf(g_phi) * cosf(g_theta),
            g_radius * cosf(g_phi) * sinf(g_theta),
            g_radius * sinf(g_phi)
        );
        mat4 V = lookAt(cam, vec3(0,0,0), vec3(0,0,1));
        mat4 P = perspective(radians(45.0f), w>0? (float)w/h : 1.6f, 0.1f, 500.0f);

        glUseProgram(prog);
        glUniform3fv(locViewPos, 1, &cam[0]);
        glUniform3fv(locLightPos, 1, &lightPos[0]);
        glUniform3fv(locAmbient, 1, &ambient[0]);
        glUniform3fv(locSpecularCol, 1, &specCol[0]);
        glUniform1f(locShininess, shininess);
        glUniform1i(locEnableSD, g_enableSD);

        // ----- Draw plane at z=0 in green or with texture -----
        mat4 Mplane = scale(mat4(1.0f), vec3(planeHalf, planeHalf, 1.0f));
        mat3 Nplane = mat3(transpose(inverse(Mplane)));
        mat4 MVPplane = P * V * Mplane;

        glUniformMatrix4fv(locModel, 1, GL_FALSE, &Mplane[0][0]);
        glUniformMatrix4fv(locMVP, 1, GL_FALSE, &MVPplane[0][0]);
        glUniformMatrix3fv(locNrmMat, 1, GL_FALSE, &Nplane[0][0]);
        if(usePlaneTex){
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, planeTex);
            glUniform1i(locUseTexture, 1);
            glUniform3f(locDiffuseCol, 1.0f, 1.0f, 1.0f);
        } else {
            glUniform1i(locUseTexture, 0);
            // Just-green rectangle
            glUniform3f(locDiffuseCol, 0.0f, 0.8f, 0.2f);
        }
        glBindVertexArray(vaoPlane);
        glDrawElements(GL_TRIANGLES, planeIndexCount, GL_UNSIGNED_INT, 0);

        // ----- Draw 8 Suzanne heads around the origin, facing outward, chin at z=0 -----
        glBindVertexArray(vaoSuz);
        glUniform1i(locUseTexture, 0); // no texture for heads by default
        glUniform3f(locDiffuseCol, 0.85f, 0.85f, 0.9f);

        for(int i=0;i<8;++i){
            float ang = i * angleStep;
            // Center on circle in XY plane
            vec3 center = vec3(R*cosf(ang), R*sinf(ang), 0.0f);

            // Model matrix: lift chin to z=0, rotate so face outward (around Z), then translate to center
            mat4 M = mat4(1.0f);
            // move so chin touches z=0
            M = translate(M, vec3(0,0, chinLift));
            // rotate to face +X (suzanne default) then rotate around Z by ang so it faces outward (tangent is +theta; outward is +radial)
            // If Suzanne faces -Z by default in your asset, adjust these. Here we assume +X front; rotate by (ang) so +X aligns with radial.
            // rotate so that the TOP (+Z) of the model faces radially outward
            // Step 1: rotate Suzanne so that its +Z aligns with +X (lying sideways)
            // Step 2: rotate around global Z by the ring angle
            //M = rotate(M, radians(90.0f), vec3(0,0,1)); // tip Suzanne on her side
            //M = rotate(M, ang, vec3(0,0,1));            // spin around the ring

            // translate to circle
            M = translate(M, center);

            mat3 N = mat3(transpose(inverse(M)));
            mat4 MVP = P * V * M;

            glUniformMatrix4fv(locModel, 1, GL_FALSE, &M[0][0]);
            glUniformMatrix4fv(locMVP, 1, GL_FALSE, &MVP[0][0]);
            glUniformMatrix3fv(locNrmMat, 1, GL_FALSE, &N[0][0]);

            glDrawElements(GL_TRIANGLES, suzIndexCount, GL_UNSIGNED_INT, 0);
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Cleanup
    glDeleteVertexArrays(1, &vaoSuz);
    glDeleteBuffers(1, &vboPosSuz);
    glDeleteBuffers(1, &vboNrmSuz);
    glDeleteBuffers(1, &vboUVSuz);
    glDeleteBuffers(1, &eboSuz);

    glDeleteVertexArrays(1, &vaoPlane);
    glDeleteBuffers(1, &vboPosPlane);
    glDeleteBuffers(1, &vboNrmPlane);
    glDeleteBuffers(1, &vboUVPlane);
    glDeleteBuffers(1, &eboPlane);

    if(planeTex) glDeleteTextures(1, &planeTex);
    glDeleteProgram(prog);
    glfwTerminate();
    return 0;
}
